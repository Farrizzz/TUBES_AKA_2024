#include <iostream>
#include <chrono> // Untuk mengukur waktu eksekusi

using namespace std;

// Fungsi Iteratif untuk menghitung jumlah deret aritmatika
int sumArithmeticIterative(int a, int d, int n) {
    int total = 0;
    for (int i = 0; i < n; ++i) {
        total += a + i * d;
    }
    return total;
}

// Fungsi Rekursif untuk menghitung jumlah deret aritmatika
int sumArithmeticRecursive(int a, int d, int n) {
    if (n == 1) {
        return a;
    }
    return (a + (n - 1) * d) + sumArithmeticRecursive(a, d, n - 1);
}

void iteratif(int a, int d, int n){
    // Hitung menggunakan metode iteratif
    auto startIterative = chrono::high_resolution_clock::now();
    int resultIterative = sumArithmeticIterative(a, d, n);
    auto endIterative = chrono::high_resolution_clock::now();

    // Hitung waktu eksekusi
    auto durationIterative = chrono::duration_cast<chrono::nanoseconds>(endIterative - startIterative).count();

    // Output hasil
    cout << "\nHasil Iteratif: " << resultIterative;
    cout << "\nWaktu eksekusi (Iteratif): " << durationIterative << " nanodetik" << endl;
    }

void rekursif(int a, int d, int n){
        // Hitung menggunakan metode rekursif
    auto startRecursive = chrono::high_resolution_clock::now();
    int resultRecursive = sumArithmeticRecursive(a, d, n);
    auto endRecursive = chrono::high_resolution_clock::now();

    // Hitung waktu eksekusi
    auto durationRecursive = chrono::duration_cast<chrono::nanoseconds>(endRecursive - startRecursive).count();

    // Output hasil
    cout << "\nHasil Rekursif: " << resultRecursive;
    cout << "\nWaktu eksekusi (Rekursif): " << durationRecursive << " nanodetik" << endl;
    }

int main() {
    int a, d, n, in;
    in = 1;
    // Input nilai awal (a), beda (d), dan jumlah suku (n)
    cout << "Masukkan nilai awal (a): ";
    cin >> a;
    cout << "Masukkan beda (d): ";
    cin >> d;
    cout << "Masukkan jumlah suku (n): ";
    cin >> n;

    while(in > 0 && in <= 2){
        cout <<"Hitung Kecepatan Eksekusi Program"<<endl;
        cout <<"1. Iteratif"<<endl;
        cout <<"2. Rekursif"<<endl;
        cout <<"0. Keluar"<<endl;
        cin >> in;
        if (in == 1){
            iteratif(a,d,n);
        }else if (in == 2){
            rekursif(a,d,n);
        }
    }
    return 0;
}
